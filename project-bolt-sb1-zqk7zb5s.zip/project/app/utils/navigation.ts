import { Frame } from '@nativescript/core';

export function navigateToJobDetail(jobId: string) {
  Frame.topmost().navigate({
    moduleName: 'views/job-detail/job-detail-page',
    context: { jobId }
  });
}

export function navigateBack() {
  Frame.topmost().goBack();
}