import { File } from '@nativescript/core';

export async function pickDocument(): Promise<File | null> {
  // TODO: Implement document picker
  return null;
}

export function getFileExtension(fileName: string): string {
  return fileName.slice(fileName.lastIndexOf('.') + 1);
}

export function isValidResumeType(fileExtension: string): boolean {
  const validTypes = ['pdf', 'doc', 'docx'];
  return validTypes.includes(fileExtension.toLowerCase());
}