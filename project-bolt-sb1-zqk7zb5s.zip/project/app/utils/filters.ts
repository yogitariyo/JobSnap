import { JobFilter } from '../models/job.model';

export function createJobFilter(params: Partial<JobFilter>): JobFilter {
  return {
    type: params.type,
    location: params.location,
    minExperience: params.minExperience,
    minSalary: params.minSalary,
    searchTerm: params.searchTerm
  };
}

export function formatSalaryRange(min: number, max: number): string {
  return `$${min.toLocaleString()} - $${max.toLocaleString()}`;
}

export function formatExperience(years: number): string {
  return `${years} ${years === 1 ? 'year' : 'years'}`;
}