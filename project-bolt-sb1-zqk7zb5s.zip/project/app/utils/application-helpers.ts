export function getStatusIcon(status: string): string {
  switch (status.toLowerCase()) {
    case 'pending':
      return '⏳';
    case 'reviewed':
      return '👀';
    case 'accepted':
      return '✅';
    case 'rejected':
      return '❌';
    default:
      return '📋';
  }
}

export function validateApplication(coverLetter: string): string[] {
  const errors: string[] = [];
  
  if (!coverLetter?.trim()) {
    errors.push('Cover letter is required');
  } else if (coverLetter.length < 100) {
    errors.push('Cover letter should be at least 100 characters');
  }
  
  return errors;
}

export function formatApplicationDate(date: Date): string {
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}