export function getNotificationIcon(type: string): string {
  switch (type) {
    case 'new_job':
      return '🔔';
    case 'application_update':
      return '📝';
    case 'saved_search':
      return '🔍';
    default:
      return '📌';
  }
}

export function formatDate(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (minutes < 60) {
    return `${minutes}m ago`;
  } else if (hours < 24) {
    return `${hours}h ago`;
  } else {
    return `${days}d ago`;
  }
}