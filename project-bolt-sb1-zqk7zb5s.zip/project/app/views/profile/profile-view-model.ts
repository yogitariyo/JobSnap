import { Observable } from '@nativescript/core';
import { UserProfile } from '../../models/user.model';
import { ResumeService } from '../../services/resume.service';

export class ProfileViewModel extends Observable {
  private _userProfile: UserProfile;
  private resumeService: ResumeService;

  constructor() {
    super();
    this.resumeService = new ResumeService();
    this.loadProfile();
  }

  async onUploadResume() {
    // TODO: Implement file picker and upload
  }

  async onDeleteResume(args: any) {
    const resume = args.object.bindingContext;
    await this.resumeService.deleteResume(resume.id);
    await this.loadProfile();
  }

  private async loadProfile() {
    // TODO: Load user profile from backend
    this._userProfile = {
      id: '1',
      fullName: 'John Doe',
      email: 'john@example.com',
      phone: '+1234567890',
      skills: ['JavaScript', 'TypeScript', 'React'],
      experience: [],
      education: [],
      resumes: []
    };
    this.notifyPropertyChange('userProfile', this._userProfile);
  }
}