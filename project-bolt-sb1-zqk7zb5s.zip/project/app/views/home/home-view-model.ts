import { Observable } from '@nativescript/core';
import { Job, JobFilter } from '../../models/job.model';

export class HomeViewModel extends Observable {
  private _jobs: Job[] = [];
  private _searchQuery: string = '';
  private _filter: JobFilter = {};

  constructor() {
    super();
    this.loadJobs();
  }

  get jobs(): Job[] {
    return this._jobs;
  }

  get searchQuery(): string {
    return this._searchQuery;
  }

  set searchQuery(value: string) {
    if (this._searchQuery !== value) {
      this._searchQuery = value;
      this.notifyPropertyChange('searchQuery', value);
      this.applyFilters();
    }
  }

  onSearch() {
    this.applyFilters();
  }

  filterByType(args: any) {
    const button = args.object;
    this._filter.type = button.text.toLowerCase() as 'government' | 'private';
    this.applyFilters();
  }

  showLocationFilter() {
    // Implement location filter dialog
  }

  showExperienceFilter() {
    // Implement experience filter dialog
  }

  showSalaryFilter() {
    // Implement salary filter dialog
  }

  private async loadJobs() {
    // TODO: Implement API call to fetch jobs
    this._jobs = [
      {
        id: '1',
        title: 'Software Engineer',
        company: 'Tech Corp',
        location: 'New York',
        type: 'private',
        experience: 3,
        salary: { min: 80000, max: 120000 },
        description: 'Looking for a skilled software engineer...',
        requirements: ['JavaScript', 'TypeScript', 'Node.js'],
        postedDate: new Date()
      }
    ];
    this.notifyPropertyChange('jobs', this._jobs);
  }

  private applyFilters() {
    // Implement filter logic
  }
}