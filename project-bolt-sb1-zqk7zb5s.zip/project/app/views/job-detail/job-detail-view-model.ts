import { Observable } from '@nativescript/core';
import { Job } from '../../models/job.model';
import { ResumeService } from '../../services/resume.service';
import { ApplicationService, JobApplication } from '../../services/application.service';

export class JobDetailViewModel extends Observable {
  private _job: Job;
  private _resumes: Array<{ id: string; name: string }> = [];
  private _selectedResumeIndex = 0;
  private _coverLetter = '';
  
  private resumeService: ResumeService;
  private applicationService: ApplicationService;

  constructor() {
    super();
    this.resumeService = new ResumeService();
    this.applicationService = new ApplicationService();
  }

  async loadJobDetails(jobId: string) {
    // TODO: Fetch job details
    await this.loadResumes();
  }

  private async loadResumes() {
    const resumes = await this.resumeService.getResumes('current-user-id');
    this._resumes = resumes;
    this.notifyPropertyChange('resumes', resumes);
  }

  get canSubmit(): boolean {
    return this._coverLetter.length > 0 && this._resumes.length > 0;
  }

  async onSubmitApplication() {
    const application: JobApplication = {
      jobId: this._job.id,
      resumeId: this._resumes[this._selectedResumeIndex].id,
      coverLetter: this._coverLetter
    };

    await this.applicationService.submitApplication(application);
    // TODO: Show success message and navigate back
  }

  get formattedSalary(): string {
    return `$${this._job.salary.min.toLocaleString()} - $${this._job.salary.max.toLocaleString()}`;
  }
}