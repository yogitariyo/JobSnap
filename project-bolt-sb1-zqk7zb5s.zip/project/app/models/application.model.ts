export interface JobApplication {
  id: string;
  jobId: string;
  resumeId: string;
  coverLetter: string;
  status: 'pending' | 'reviewed' | 'accepted' | 'rejected';
  appliedAt: Date;
  lastUpdated: Date;
}

export interface ApplicationStatus {
  current: string;
  history: {
    status: string;
    date: Date;
    note?: string;
  }[];
}