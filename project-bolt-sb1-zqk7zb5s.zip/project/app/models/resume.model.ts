export interface Resume {
  id: string;
  name: string;
  url: string;
  fileType: string;
  createdAt: Date;
  lastUsed?: Date;
  size: number;
}

export interface ResumeStats {
  totalApplications: number;
  lastApplication?: Date;
  viewCount: number;
}