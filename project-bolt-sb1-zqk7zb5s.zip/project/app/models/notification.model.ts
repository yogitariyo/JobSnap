export interface JobNotification {
  id: string;
  jobId: string;
  title: string;
  type: 'new_job' | 'application_update' | 'saved_search';
  message: string;
  createdAt: Date;
  read: boolean;
}

export interface NotificationPreferences {
  newJobs: boolean;
  applicationUpdates: boolean;
  savedSearches: boolean;
  emailNotifications: boolean;
}