export interface UserProfile {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  skills: string[];
  experience: {
    company: string;
    position: string;
    duration: string;
  }[];
  education: {
    degree: string;
    institution: string;
    year: string;
  }[];
  resumes: {
    id: string;
    name: string;
    url: string;
  }[];
}