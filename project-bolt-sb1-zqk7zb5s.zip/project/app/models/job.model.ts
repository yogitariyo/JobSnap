export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: 'government' | 'private';
  experience: number;
  salary: {
    min: number;
    max: number;
  };
  description: string;
  requirements: string[];
  postedDate: Date;
}

export interface JobFilter {
  type?: 'government' | 'private';
  location?: string;
  minExperience?: number;
  minSalary?: number;
  searchTerm?: string;
}